[CmdletBinding()]
param(
    [Parameter(ParameterSetName = "file_id")]
    [string]$FileId,

    [Parameter(ParameterSetName = "latest")]
    [switch]$Latest,

    [string]$Destination = "",
    [switch]$PassThru
)

$endpoint = "https://bot-29-nx0w.onrender.com"

# Если не указан FileId и не Latest — показываем справку
if ([string]::IsNullOrEmpty($FileId) -and -not $Latest) {
    Write-Host "=== Восстановление my_best_work ===" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Укажи file_id из backup-уведомления:"
    Write-Host "  powershell -File SCRIPTs\restore.ps1 -FileId <file_id>"
    Write-Host ""
    Write-Host "Либо скачай последний бэкап с сервера:"
    Write-Host "  Сначала: GET $endpoint/api/agents/responses"
    Write-Host "  Найди file_id в ответе, затем укажи его."
    Write-Host ""
    Write-Host "После восстановления нужно настроить:"
    Write-Host "  1. SSH ключ: ssh-keygen -t ed25519 и добавить в GitHub (alexsmy)"
    Write-Host "  2. Переменные окружения (User):"
    Write-Host "     setx AGENTS_TUNNEL_SECRET <значение>"
    Write-Host "     setx TELEGRAM_TUNNEL_SECRET <значение>"
    Write-Host "  3. Git config:"
    Write-Host "     git config --global user.name alexs"
    Write-Host "     git config --global user.email alex.smyslov@mail.ru"
    Write-Host ""
    Write-Host "Подробнее: https://github.com/alexsmy/bot_29"
    exit 0
}

if ([string]::IsNullOrEmpty($Destination)) {
    $Destination = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
}

Write-Verbose "Destination: $Destination"

if ($Latest) {
    Write-Error "Автопоиск последнего бэкапа пока не поддерживается. Укажи -FileId вручную."
    exit 1
}

# Скачиваем архив
$downloadUrl = "$endpoint/files/open/$FileId"
$tempDir = Join-Path $env:TEMP "opencode-restore"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
$zipPath = Join-Path $tempDir "restore.zip"

Write-Verbose "Downloading: $downloadUrl"
try {
    Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath
} catch {
    Write-Error "Download failed: $_"
    exit 1
}

Write-Verbose "Downloaded: $( (Get-Item $zipPath).Length ) bytes"

# Распаковываем
Add-Type -AssemblyName System.IO.Compression.FileSystem
try {
    if (Test-Path $Destination) {
        $backupDir = Join-Path (Split-Path $Destination) "my_best_work_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        Rename-Item -Path $Destination -NewName $backupDir -ErrorAction SilentlyContinue
        Write-Warning "Существующая папка переименована в: $backupDir"
    }
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $Destination)
} catch {
    Write-Error "Extract failed: $_"
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    exit 1
}

Remove-Item $zipPath -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "=== Восстановление завершено ===" -ForegroundColor Green
Write-Host "Папка: $Destination"
Write-Host ""
Write-Host "Теперь нужно:"
Write-Host "  1. Установить Python (C:\Python312) и Node.js"
Write-Host "  2. Настроить SSH: ssh-keygen -t ed25519 → cat ~/.ssh/id_ed25519.pub → добавить в https://github.com/settings/keys"
Write-Host "  3. Установить переменные окружения User (от админа):"
Write-Host "     setx AGENTS_TUNNEL_SECRET <значение из старого ПК>"
Write-Host "  4. Настроить git:"
Write-Host "     git config --global user.name alexs"
Write-Host "     git config --global user.email alex.smyslov@mail.ru"
Write-Host "  5. Клонировать серверный репо (если нужно):"
Write-Host "     git clone git@github.com:alexsmy/bot_29.git"
Write-Host "  6. Открыть opencode в папке:"
Write-Host "     cd $Destination && opencode"
Write-Host ""

$output = @{
    action        = "restored"
    destination   = $Destination
    files         = (Get-ChildItem $Destination -Recurse | Measure-Object).Count
}

if ($PassThru) { return $output }
Write-Output "RESTORE_OK"
