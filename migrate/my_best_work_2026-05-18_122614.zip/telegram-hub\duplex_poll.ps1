<#
.SYNOPSIS
  Duplex polling: каждые N секунд проверяет Telegram inbox.
  Если есть новые сообщения — пишет в data/duplex_pending.json.

.ЗАПУСК (в отдельном окне PowerShell)
  powershell -ExecutionPolicy Bypass -File telegram-hub\duplex_poll.ps1 -Interval 15

.ОСТАНОВКА
  Закрыть окно PowerShell, либо нажать Ctrl+C.
#>

param(
    [int]$Interval = 15,
    [switch]$Verbose,
    [switch]$Quiet
)

$INBOX_URL     = "https://bot-29-nx0w.onrender.com/api/telegram/inbox"
$ACK_URL       = "https://bot-29-nx0w.onrender.com/api/telegram/inbox/ack"
$PENDING_FILE  = Join-Path -Path $PSScriptRoot -ChildPath ".." | Join-Path -ChildPath "data" | Join-Path -ChildPath "duplex_pending.json"

$SECRET = [System.Environment]::GetEnvironmentVariable("AGENTS_TUNNEL_SECRET", "User")
if (-not $SECRET) {
    $SECRET = [System.Environment]::GetEnvironmentVariable("AGENTS_TUNNEL_SECRET", "Process")
}

function Write-Log {
    param([string]$Msg)
    if (-not $Quiet) {
        $time = Get-Date -Format "HH:mm:ss"
        Write-Host "[$time] $Msg" -ForegroundColor Cyan
    }
}

function Get-Utf8Json {
    param([string]$Url)
    $req = [System.Net.WebRequest]::Create($Url)
    $req.Method = "GET"
    $req.ContentType = "application/json; charset=utf-8"
    if ($SECRET) {
        $req.Headers.Add("x-agents-tunnel-secret", $SECRET)
    }
    $resp = $req.GetResponse()
    $stream = $resp.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
    $text = $reader.ReadToEnd()
    $reader.Close()
    $resp.Close()
    return $text
}

function Post-Ack {
    $req = [System.Net.WebRequest]::Create($ACK_URL)
    $req.Method = "POST"
    $req.ContentLength = 0
    if ($SECRET) {
        $req.Headers.Add("x-agents-tunnel-secret", $SECRET)
    }
    $resp = $req.GetResponse()
    $resp.Close()
}

# Проверка связи
try {
    $null = Get-Utf8Json -Url $INBOX_URL
} catch {
    Write-Log "Сервер не отвечает. Проверь Render:"
    Write-Log "  https://bot-29-nx0w.onrender.com/api/agents/health"
    exit 1
}

Write-Log "Duplex polling запущен. Интервал: ${Interval}с"
Write-Log "  Остановка: закрой это окно или нажми Ctrl+C"
Write-Log ""

$noActivityCount = 0

while ($true) {
    try {
        $jsonText = Get-Utf8Json -Url $INBOX_URL
        $data = $jsonText | ConvertFrom-Json

        if ($data.ok -and $data.count -gt 0) {
            $noActivityCount = 0

            # Сохраняем как UTF-8 байты (без BOM)
            $dir = Split-Path -Parent $PENDING_FILE
            if (-not (Test-Path $dir)) {
                New-Item -ItemType Directory -Path $dir -Force | Out-Null
            }
            $utf8Bytes = [System.Text.Encoding]::UTF8.GetBytes($jsonText)
            [System.IO.File]::WriteAllBytes($PENDING_FILE, $utf8Bytes)

            Write-Log "Новое сообщение от Telegram"
            if ($Verbose) {
                Write-Log "  сохранено в $PENDING_FILE"
            }

            # ACK
            Post-Ack
            if ($Verbose) {
                Write-Log "  ack отправлен"
            }
        } else {
            $noActivityCount = $noActivityCount + 1
            if ($Verbose) {
                $remainder = $noActivityCount % 20
                if ($remainder -eq 0) {
                    Write-Log "  тишина... проверок: $noActivityCount"
                }
            }
        }
    } catch {
        if ($Verbose) {
            Write-Log "Ошибка: $_"
        }
    }

    Start-Sleep -Seconds $Interval
}
