"""
Duplex polling: каждые N секунд проверяет Telegram inbox.
Если есть новые сообщения — пишет в data/duplex_pending.json.

ЗАПУСК (в отдельном окне):
  python telegram-hub/duplex_poll.py --interval 15

ОСТАНОВКА:
  Ctrl+C или закрыть окно.
"""

import json
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


INBOX_URL = "https://bot-29-nx0w.onrender.com/api/telegram/inbox"
ACK_URL = "https://bot-29-nx0w.onrender.com/api/telegram/inbox/ack"
PENDING_FILE = Path(__file__).resolve().parent.parent / "data" / "duplex_pending.json"


def get_secret():
    return os.environ.get("AGENTS_TUNNEL_SECRET") or None


def fetch_json(url, secret=None):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "opencode-duplex")
    if secret:
        req.add_header("x-agents-tunnel-secret", secret)
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


def post_ack(secret=None):
    req = urllib.request.Request(ACK_URL, method="POST", data=b"")
    req.add_header("Content-Type", "application/json")
    if secret:
        req.add_header("x-agents-tunnel-secret", secret)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def log(msg, verbose=False):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--interval", type=int, default=15, help="Poll interval in seconds")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    args = parser.parse_args()

    secret = get_secret()
    if secret:
        log("Secret: найден", verbose=True)
    else:
        log("Secret: не найден (работаю без аутентификации)", verbose=True)

    # Проверка связи
    try:
        fetch_json(INBOX_URL, secret)
    except Exception as e:
        log(f"Сервер не отвечает: {e}")
        sys.exit(1)

    log(f"Duplex polling запущен. Интервал: {args.interval}с")
    log("Остановка: Ctrl+C")
    log("")

    no_activity = 0

    while True:
        try:
            data = fetch_json(INBOX_URL, secret)

            if data.get("ok") and data.get("count", 0) > 0:
                no_activity = 0

                # Сохраняем
                PENDING_FILE.parent.mkdir(parents=True, exist_ok=True)
                PENDING_FILE.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2),
                    encoding="utf-8"
                )

                texts = []
                for msg in data.get("messages", []):
                    t = msg.get("text", "")[:60]
                    texts.append(t)
                log(f"Новое сообщение: {' | '.join(texts)}")

                # ACK
                result = post_ack(secret)
                if verbose := args.verbose:
                    log(f"ack: {result}")

            else:
                no_activity += 1
                if args.verbose and no_activity % 20 == 0:
                    log(f"тишина... проверок: {no_activity}")

        except KeyboardInterrupt:
            log("Остановлен")
            break
        except Exception as e:
            if args.verbose:
                log(f"Ошибка: {e}")

        time.sleep(args.interval)


if __name__ == "__main__":
    main()
