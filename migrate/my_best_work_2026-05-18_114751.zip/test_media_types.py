"""Upload a real photo to FileVault and send via Telegram"""
import asyncio, json, os
import httpx

MCP = "https://bot-29-nx0w.onrender.com/mcp/"
FV = "https://bot-29-nx0w.onrender.com/api/filevault/upload"

PHOTO_PATH = r"C:\Users\Alex1\Downloads\Telegram Desktop\GigaChat.jpg"

async def main():
    async with httpx.AsyncClient(timeout=60) as cl:
        # MCP session
        r = await cl.get(MCP, headers={"Accept": "text/event-stream"}, timeout=10)
        sid = r.headers.get("mcp-session-id", "")
        await cl.post(MCP, json={"jsonrpc":"2.0","id":"1","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}, headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid})

        # Upload real photo
        print("Uploading photo...")
        with open(PHOTO_PATH, "rb") as f:
            photo_bytes = f.read()
        print(f"  File size: {len(photo_bytes)} bytes")

        files = {"files": ("GigaChat.jpg", photo_bytes, "image/jpeg")}
        r2 = await cl.post(FV, files=files, timeout=30)
        fu = r2.json()["files"][0]["public_url"]
        print(f"  FileVault URL: {fu}")

        # Send as photo
        print("\nSending via MCP tool...")
        resp = await cl.post(MCP, json={"jsonrpc":"2.0","id":"1","method":"tools/call","params":{"name":"send_telegram_message","arguments":{"text":"<b>Real photo test</b>","file_url":fu,"file_name":"GigaChat.jpg","parse_mode":"html","action":"send"}}}, headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid}, timeout=60)
        result = resp.json()
        if "result" in result:
            print(f"  OK: {result['result']['content'][0]['text'][:200]}")
        else:
            print(f"  FAIL: {json.dumps(result.get('error',{}), ensure_ascii=True)[:300]}")

asyncio.run(main())
