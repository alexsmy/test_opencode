"""Upload MCP tool to server"""
import json, os, urllib.request

secret = os.environ.get("AGENTS_TUNNEL_SECRET", "").strip()

with open(r"C:\Users\Alex1\Downloads\my_best_work\agents-hub\mcp_tools_examples\send_telegram_message.py", "r", encoding="utf-8") as f:
    code = f.read()

desc = "Universal Telegram sender: text, files, edit. Supports PDF/JPG/MP4 attachments via URL."
body = {"name": "send_telegram_message", "code": code, "description": desc}
data = json.dumps(body, ensure_ascii=False).encode("utf-8")

print(f"Code: {len(code.splitlines())} lines, {len(code)} chars")
print(f"JSON: {len(data)} bytes")

req = urllib.request.Request(
    "https://bot-29-nx0w.onrender.com/api/agents/mcp-tools/register",
    data=data,
    headers={
        "Content-Type": "application/json; charset=utf-8",
        "X-Agents-Tunnel-Secret": secret,
    },
    method="POST",
)
try:
    with urllib.request.urlopen(req) as resp:
        result = json.loads(resp.read().decode("utf-8"))
        print("OK:", json.dumps(result, indent=2, ensure_ascii=False))
except urllib.error.HTTPError as e:
    print("Status:", e.code)
    print("Body:", e.read().decode("utf-8"))
