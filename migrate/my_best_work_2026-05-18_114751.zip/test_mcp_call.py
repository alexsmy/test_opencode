"""Post-deploy test: verify built-in send_telegram_message"""
import asyncio, json
import httpx

MCP = "https://bot-29-nx0w.onrender.com/mcp/"

async def main():
    async with httpx.AsyncClient(timeout=60) as cl:
        r = await cl.get(MCP, headers={"Accept": "text/event-stream"}, timeout=10)
        sid = r.headers.get("mcp-session-id", "")
        await cl.post(MCP, json={"jsonrpc":"2.0","id":"1","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}, headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid})

        # 1. List tools
        r = await cl.post(MCP, json={"jsonrpc":"2.0","id":"2","method":"tools/list","params":{}}, headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid})
        tools = [t["name"] for t in r.json()["result"]["tools"]]
        print(f"Tools: {tools}")

        assert "send_telegram_message" in tools, "MISSING!"

        # 2. Text
        print("\nText...")
        r = await cl.post(MCP, json={"jsonrpc":"2.0","id":"3","method":"tools/call","params":{"name":"send_telegram_message","arguments":{"text":"<b>Post-deploy test OK</b>","parse_mode":"html","action":"send"}}}, headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid})
        assert "result" in r.json(), f"Text failed: {r.json()}"
        print(f"  {r.json()['result']['content'][0]['text'][:100]}")

        # 3. Upload photo to FileVault and send
        print("\nPhoto...")
        with open(r"C:\Users\Alex1\Downloads\Telegram Desktop\GigaChat.jpg", "rb") as f:
            r2 = await cl.post("https://bot-29-nx0w.onrender.com/api/filevault/upload", files={"files": ("test.jpg", f, "image/jpeg")})
        fu = r2.json()["files"][0]["public_url"]
        r = await cl.post(MCP, json={"jsonrpc":"2.0","id":"4","method":"tools/call","params":{"name":"send_telegram_message","arguments":{"text":"<b>Post-deploy photo</b>","file_url":fu,"file_name":"test.jpg","parse_mode":"html","action":"send"}}}, headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid})
        assert "result" in r.json(), f"Photo failed: {r.json()}"
        print(f"  {r.json()['result']['content'][0]['text'][:100]}")

        print("\nALL OK")

asyncio.run(main())
