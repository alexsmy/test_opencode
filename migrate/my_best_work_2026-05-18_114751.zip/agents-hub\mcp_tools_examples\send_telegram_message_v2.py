import os
import httpx

async def send_telegram_message(
    text: str,
    parse_mode: str = "html",
    action: str = "send"
) -> str:
    """Send a message to Telegram. text: message text. parse_mode: html/markdownv2/plain. action: send/update."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if not token or not chat_id:
        return "ERROR: TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set"

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode.upper() if parse_mode != "plain" else "",
        "disable_web_page_preview": True,
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(url, json=payload)
        data = resp.json()

    if not data.get("ok"):
        return f"ERROR: {data.get('description', 'unknown')}"

    return f"OK: message sent (id: {data['result']['message_id']})"
