async def test_echo(text: str = "Hello!") -> str:
    """Простой тестовый инструмент: возвращает эхо"""
    return f"Echo: {text}"
