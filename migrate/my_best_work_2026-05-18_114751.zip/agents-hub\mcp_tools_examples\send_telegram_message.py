r"""
Universal MCP tool for sending messages and files to Telegram.

Usage:
  @weather_agents send_telegram_message text="Hello!"
  @weather_agents send_telegram_message text="Report" file_url="https://..."
  @weather_agents send_telegram_message text="Photo" file_url="https://..." media_type="photo"
"""

import asyncio
import os
from typing import Literal

import httpx


# ============================================================
# ВНУТРЕННИЕ ФУНКЦИИ
# ============================================================

def _get_settings() -> dict:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if not token or not chat_id:
        raise RuntimeError("TELEGRAM_BOT_TOKEN или TELEGRAM_CHAT_ID не заданы на сервере")
    return {"token": token, "chat_id": chat_id}


# Маппинг расширений -> метод Telegram API
_EXT_TO_METHOD = {
    # Фото
    ".jpg": "sendPhoto", ".jpeg": "sendPhoto", ".png": "sendPhoto",
    ".gif": "sendPhoto", ".webp": "sendPhoto", ".bmp": "sendPhoto",
    # Видео
    ".mp4": "sendVideo", ".avi": "sendVideo", ".mov": "sendVideo",
    ".mkv": "sendVideo", ".webm": "sendVideo",
    # Аудио (музыка)
    ".mp3": "sendAudio", ".wav": "sendAudio", ".flac": "sendAudio",
    # Голосовые (.ogg с OPUS — воспроизведение через play)
    ".ogg": "sendVoice", ".oga": "sendVoice",
}

# Маппинг метода -> имя поля в multipart-запросе
_METHOD_TO_FIELD = {
    "sendPhoto": "photo",
    "sendVideo": "video",
    "sendAudio": "audio",
    "sendVoice": "voice",
    "sendDocument": "document",
}

# Маппинг коротких имён -> метод
_SHORT_TO_METHOD = {
    "photo": "sendPhoto", "image": "sendPhoto",
    "video": "sendVideo",
    "audio": "sendAudio", "music": "sendAudio",
    "voice": "sendVoice",
    "document": "sendDocument", "file": "sendDocument",
}


def _detect_file_type(url: str, media_type: str = "", file_name: str = "") -> str:
    if media_type:
        method = _SHORT_TO_METHOD.get(media_type.lower())
        if method:
            return method
    # Сначала проверяем file_name (самый надёжный)
    target = file_name.lower() if file_name else url.lower()
    for ext, method in _EXT_TO_METHOD.items():
        if target.endswith(ext):
            return method
    # Если в URL нет расширения — проверяем URL после последнего /
    target = url.lower()
    for ext, method in _EXT_TO_METHOD.items():
        if target.endswith(ext):
            return method
    return "sendDocument"


async def _download_file(url: str) -> tuple[bytes, str]:
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        ct = resp.headers.get("content-type", "")
        if "image" in ct:
            ext = ct.split("/")[-1].split(";")[0]
        else:
            from urllib.parse import urlparse
            path = urlparse(url).path
            ext = path.split(".")[-1] if "." in path else "bin"
        return resp.content, ext


async def _call_telegram_api(method: str, payload: dict, token: str) -> dict:
    url = f"https://api.telegram.org/bot{token}/{method}"
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(url, json=payload)
        data = resp.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram API ({method}): {data.get('description', 'неизвестная ошибка')}")
    return data


# ============================================================
# MCP-ИНСТРУМЕНТ
# ============================================================

async def send_telegram_message(
    text: str,
    file_url: str = "",
    file_name: str = "",
    parse_mode: Literal["html", "markdownv2", "plain"] = "html",
    action: Literal["send", "update"] = "send",
    media_type: str = "",
) -> str:
    """
    Отправить сообщение в Telegram.

    Параметры:
      text — текст сообщения (HTML-разметка если parse_mode=html)
      file_url — (опционально) ссылка на файл: PDF, JPG, PNG, MP4, MP3, OGG и т.д.
      file_name — имя файла для отображения
      parse_mode — html (по умолчанию), markdownv2, plain
      action — 'send' (новое) или 'update' (редактировать последнее)
      media_type — принудительный тип: 'photo','image','video','audio','music','voice','document','file'
                   Если не указан — определяется по расширению файла

    Автоопределение media_type:
      .jpg/.jpeg/.png/.gif/.webp/.bmp → фото (sendPhoto)
      .mp4/.avi/.mov/.mkv/.webm       → видео (sendVideo)
      .mp3/.wav/.flac                 → аудио-файл (sendAudio)
      .ogg/.oga                       → голосовое (sendVoice) — кнопка Play!
      всё остальное                   → документ (sendDocument)
    """
    settings = _get_settings()
    token = settings["token"]
    chat_id = settings["chat_id"]

    # --- Отправка с файлом ---
    if file_url:
        file_bytes, ext = await _download_file(file_url)
        file_type = _detect_file_type(file_url, media_type, file_name)
        field_name = _METHOD_TO_FIELD.get(file_type, "document")
        if not file_name:
            file_name = file_url.split("/")[-1].split("?")[0]

        url = f"https://api.telegram.org/bot{token}/{file_type}"
        timeout = httpx.Timeout(60.0)

        caption = text
        files = {}
        data = {"chat_id": chat_id}

        # Для sendPhoto и sendVideo caption идёт отдельным полем
        # Для sendAudio, sendVoice, sendDocument caption тоже поддерживается
        if caption:
            data["caption"] = caption
            if parse_mode != "plain":
                data["parse_mode"] = parse_mode.upper() if parse_mode == "html" else "MarkdownV2"

        # Имя файла и расширение для поля
        safe_name = file_name or f"file.{ext}"

        # voice и audio не видят filename — только файл
        files[field_name] = (safe_name, file_bytes)

        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, data=data, files=files)
            result = resp.json()

        # Fallback: фото не прошло → пробуем как документ
        if not result.get("ok") and file_type == "sendPhoto":
            desc = result.get("description", "")
            if "can't parse" in desc.lower() or "wrong file" in desc.lower():
                files = {"document": (safe_name, file_bytes)}
                async with httpx.AsyncClient(timeout=timeout) as client:
                    resp2 = await client.post(
                        f"https://api.telegram.org/bot{token}/sendDocument",
                        data={"chat_id": chat_id, "caption": caption},
                        files=files,
                    )
                    result = resp2.json()

        if not result.get("ok"):
            desc = result.get("description", "неизвестная ошибка")
            return f"Error sending file: {desc}"

        return (
            f"Sent to Telegram\n"
            f"Type: {file_type} | {file_name}"
        )

    # --- Текстовое сообщение ---
    if action == "update":
        message_id = None
        msg_file = "/tmp/last_telegram_message_id.txt"
        try:
            loop = asyncio.get_running_loop()
            stored = await asyncio.to_thread(
                lambda: open(msg_file).read().strip() if os.path.exists(msg_file) else ""
            )
            if stored:
                message_id = int(stored)
        except (ValueError, OSError):
            message_id = None

        if message_id:
            try:
                data = await _call_telegram_api(
                    "editMessageText",
                    {
                        "chat_id": chat_id,
                        "message_id": message_id,
                        "text": text,
                        "parse_mode": parse_mode.upper() if parse_mode != "plain" else "",
                        "disable_web_page_preview": True,
                    },
                    token,
                )
                return f"Edited (id: {data['result']['message_id']})"
            except RuntimeError:
                pass

    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode.upper() if parse_mode != "plain" else "",
        "disable_web_page_preview": True,
    }

    try:
        data = await _call_telegram_api("sendMessage", payload, token)
    except RuntimeError as e:
        return f"Error: {e}"

    message_id = data["result"]["message_id"]

    try:
        loop = asyncio.get_running_loop()
        await asyncio.to_thread(
            lambda: open("/tmp/last_telegram_message_id.txt", "w").write(str(message_id))
        )
    except OSError:
        pass

    return f"Sent to Telegram (id: {message_id})"
