"""Benchmark: compare call scenarios"""
import asyncio, json, os, time
import httpx

SERVER = "https://bot-29-nx0w.onrender.com"

async def run_test(label, with_file):
    async with httpx.AsyncClient() as cl:
        # Create session
        r = await cl.get(f"{SERVER}/mcp/", headers={"Accept": "text/event-stream"}, timeout=10)
        sid = r.headers.get("mcp-session-id", "")
        await cl.post(f"{SERVER}/mcp/",
            json={"jsonrpc":"2.0","id":"1","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}},
            headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid}, timeout=10)

        # Upload if needed
        file_url = None
        if with_file:
            data = json.dumps({"ts": time.time()}).encode()
            r = await cl.post(f"{SERVER}/api/filevault/upload",
                files={"files": ("test.json", data, "application/json")}, timeout=10)
            file_url = r.json()["files"][0]["public_url"]

        # Measure tool call
        args = {"text": f"<b>{label}</b>", "parse_mode": "html", "action": "send"}
        if file_url:
            args["file_url"] = file_url
            args["file_name"] = "test.json"

        t0 = time.perf_counter()
        r = await cl.post(f"{SERVER}/mcp/",
            json={"jsonrpc":"2.0","id":"3","method":"tools/call","params":{"name":"send_telegram_message","arguments":args}},
            headers={"Content-Type":"application/json","Accept":"application/json","mcp-session-id":sid}, timeout=30)
        t1 = time.perf_counter()

        ms = (t1 - t0) * 1000
        status = "OK" if "result" in r.json() else "FAIL"
        return ms, status

async def main():
    print("=== BENCHMARK: send_telegram_message ===\n")

    # Warmup
    await run_test("warmup", True)

    # Run each test 3 times, take best
    for label, with_file in [("Text only", False), ("Text + file", True)]:
        times = []
        for i in range(3):
            ms, status = await run_test(f"{label} #{i+1}", with_file)
            times.append(ms)
            print(f"  {label}: {ms:.0f}ms [{status}]")
        best = min(times)
        avg = sum(times) / len(times)
        print(f"  >> Best: {best:.0f}ms  Avg: {avg:.0f}ms\n")

asyncio.run(main())
