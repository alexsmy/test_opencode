r"""
Universal MCP tool for sending messages and files to Telegram.

Usage:
  @weather_agents send_telegram_message text="Hello!"
  @weather_agents send_telegram_message text="Report" file_url="https://..."
"""

import asyncio
import os
from typing import Literal

import httpx


# ============================================================
# ВНУТРЕННИЕ ФУНКЦИИ (не видны в MCP — начинаются с _)
# ============================================================

def _get_settings() -> dict:
    """
    Загрузить настройки Telegram из переменных окружения сервера.
    TELEGRAM_BOT_TOKEN — токен бота
    TELEGRAM_CHAT_ID — ID чата для отправки
    """
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if not token or not chat_id:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN или TELEGRAM_CHAT_ID не заданы на сервере"
        )
    return {"token": token, "chat_id": chat_id}


def _detect_file_type(url: str) -> str:
    """
    Определить тип медиа по расширению файла в URL.
    Возвращает метод Telegram API: sendDocument, sendPhoto, sendVideo.
    """
    lower = url.lower()
    # Изображения
    if any(lower.endswith(ext) for ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp")):
        return "sendPhoto"
    # Видео
    if any(lower.endswith(ext) for ext in (".mp4", ".avi", ".mov", ".mkv", ".webm")):
        return "sendVideo"
    # Аудио
    if any(lower.endswith(ext) for ext in (".mp3", ".wav", ".ogg", ".flac")):
        return "sendAudio"
    # Всё остальное (PDF, ZIP, документы) — как документ
    return "sendDocument"


async def _download_file(url: str) -> tuple[bytes, str]:
    """
    Скачать файл по URL.
    Возвращает (содержимое, расширение).
    """
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        # Определяем расширение из Content-Type или URL
        ct = resp.headers.get("content-type", "")
        if "image" in ct:
            ext = ct.split("/")[-1].split(";")[0]
        else:
            # Берём расширение из URL
            from urllib.parse import urlparse
            path = urlparse(url).path
            ext = path.split(".")[-1] if "." in path else "bin"
        return resp.content, ext


async def _call_telegram_api(method: str, payload: dict, token: str) -> dict:
    """
    Вызвать Telegram Bot API.
    """
    url = f"https://api.telegram.org/bot{token}/{method}"
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(url, json=payload)
        data = resp.json()
    if not data.get("ok"):
        error_desc = data.get("description", "неизвестная ошибка")
        raise RuntimeError(f"Telegram API ({method}): {error_desc}")
    return data


# ============================================================
# MCP-ИНСТРУМЕНТ (виден opencode через MCP)
# ============================================================

async def send_telegram_message(
    text: str,
    file_url: str = "",
    file_name: str = "",
    parse_mode: Literal["html", "markdownv2", "plain"] = "html",
    action: Literal["send", "update"] = "send",
) -> str:
    """
    Отправить сообщение в Telegram.

    Параметры:
      text — текст сообщения (поддерживает HTML-разметку, если parse_mode=html)
      file_url — (опционально) прямая ссылка на файл: PDF, JPG, PNG, MP4, ZIP и т.д.
      file_name — (опционально) имя файла для отображения в Telegram
      parse_mode — формат текста: html (по умолчанию), markdownv2, plain
      action — 'send' (новое сообщение) или 'update' (заменить последнее)

    Примеры:
      1. Простое текстовое сообщение:
         send_telegram_message(text="Привет из MCP!")
      2. С файлом:
         send_telegram_message(
           text="Смотри отчёт",
           file_url="https://example.com/report.pdf",
           file_name="Отчёт.pdf"
         )
      3. Обновить существующее:
         send_telegram_message(
           text="Обновлённые данные",
           action="update"
         )
    """
    settings = _get_settings()
    token = settings["token"]
    chat_id = settings["chat_id"]

    # --- Если есть файл — отправляем медиа ---
    if file_url:
        # Скачиваем файл
        file_bytes, ext = await _download_file(file_url)
        file_type = _detect_file_type(file_url)
        if not file_name:
            # Берём имя из URL, если не указано
            file_name = file_url.split("/")[-1].split("?")[0]

        # Формируем multipart-запрос к Telegram
        url = f"https://api.telegram.org/bot{token}/{file_type}"
        timeout = httpx.Timeout(60.0)

        # caption = подпись под медиа (поддерживает HTML)
        caption = text if parse_mode == "plain" else text

        files = {}
        data = {
            "chat_id": chat_id,
            "caption": caption,
        }
        if parse_mode != "plain":
            data["parse_mode"] = parse_mode.upper() if parse_mode == "html" else "MarkdownV2"

        # Для sendPhoto используем photo, для остальных — document
        if file_type == "sendPhoto":
            files["photo"] = (file_name or "image." + ext, file_bytes)
        else:
            files["document"] = (file_name or "file." + ext, file_bytes)

        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, data=data, files=files)
            result = resp.json()

        if not result.get("ok"):
            desc = result.get("description", "неизвестная ошибка")
            # Если фото не подошло — пробуем как документ
            if file_type == "sendPhoto" and "can't parse" in desc.lower():
                # Повторяем как документ
                files = {"document": (file_name or "image." + ext, file_bytes)}
                async with httpx.AsyncClient(timeout=timeout) as client:
                    resp2 = await client.post(
                        f"https://api.telegram.org/bot{token}/sendDocument",
                        data={"chat_id": chat_id, "caption": caption},
                        files=files,
                    )
                    result = resp2.json()

            if not result.get("ok"):
                desc2 = result.get("description", "неизвестная ошибка")
                return f"❌ Ошибка отправки файла: {desc2}"

        return (
            f"✅ Файл отправлен в Telegram\n"
            f"📎 {file_name}\n"
            f"💬 {text[:100]}{'…' if len(text) > 100 else ''}"
        )

    # --- Текстовое сообщение (без файла) ---
    if action == "update":
        # Пытаемся редактировать — сначала читаем message_id из файла
        message_id = None
        msg_file = "/tmp/last_telegram_message_id.txt"
        try:
            loop = asyncio.get_running_loop()
            # Используем asyncio.to_thread для чтения файла без блокировки
            stored = await asyncio.to_thread(
                lambda: open(msg_file).read().strip() if os.path.exists(msg_file) else ""
            )
            if stored:
                message_id = int(stored)
        except (ValueError, OSError):
            message_id = None

        if message_id:
            try:
                data = await _call_telegram_api(
                    "editMessageText",
                    {
                        "chat_id": chat_id,
                        "message_id": message_id,
                        "text": text,
                        "parse_mode": parse_mode.upper() if parse_mode != "plain" else "",
                        "disable_web_page_preview": True,
                    },
                    token,
                )
                return f"✅ Сообщение отредактировано (id: {data['result']['message_id']})"
            except RuntimeError as e:
                # Если редактировать не вышло — шлём новое
                pass

    # Отправка нового сообщения
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode.upper() if parse_mode != "plain" else "",
        "disable_web_page_preview": True,
    }

    try:
        data = await _call_telegram_api("sendMessage", payload, token)
    except RuntimeError as e:
        return f"❌ Ошибка отправки: {e}"

    message_id = data["result"]["message_id"]

    # Сохраняем message_id для возможности редактирования
    try:
        loop = asyncio.get_running_loop()
        await asyncio.to_thread(
            lambda: open("/tmp/last_telegram_message_id.txt", "w").write(str(message_id))
        )
    except OSError:
        pass  # Не критично

    return (
        f"✅ Сообщение отправлено в Telegram (id: {message_id})\n"
        f"💬 {text[:150]}{'…' if len(text) > 150 else ''}"
    )
