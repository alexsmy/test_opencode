# Пользователь

## Основное
- Имя: alexs
- Позывной: alexs
- Язык общения: русский
- Модель по умолчанию: opencode/deepseek-v4-flash-free
- Часовой пояс: Europe/Moscow (UTC+3)

## Контакты
- GitHub: alexsmy (https://github.com/alexsmy)
- Email: alex.smyslov@mail.ru

## Предпочтения
- Уведомления в Telegram: включены (можно отключить через `/tg off`)
- Уровень уведомлений: all (все события)
- Telegram бот: @imgtestlivebot
- Авто-синхронизация после каждой задачи: включена
- Синхронизация при старте сессии: включена
- Синхронизация при завершении сессии: включена

## Узлы (ноды)
- `notebook-win10` — ноутбук Windows 10 (PowerShell)
- `notebook-win11` — ноутбук Windows 11 — **текущий** (PowerShell)
- `server` — Render сервер (Alpine Linux, sh/curl)

## Репозиторий синхронизации
- GitHub: https://github.com/ninamc4e/my_ai_opencode_server
- Ветка: main
- Назначение: единый центр для HANDOVER.md, CONTEXT.md, USER.md
