# OpenCode knowledge map

Этот каталог — разнесённые по ролям инструкции. Каждая тема живёт в своём файле.

## Читать после перезапуска
1. `AGENTS.md`
2. `CONTEXT.md`
3. `USER.md`
4. `docs/opencode/project.md`
5. `docs/opencode/nodes.md`
6. `docs/opencode/workflow.md`
7. `docs/opencode/sync.md`
8. `docs/opencode/telegram.md`
9. `docs/opencode/backup-restore.md`
10. `docs/opencode/mcp-agents.md`

## Правило обновления
- Один файл — одна тема.
- Стабильные правила — в `AGENTS.md`.
- Текущее состояние — в `CONTEXT.md`.
- Предпочтения — в `USER.md`.
- Всё остальное — в тематических файлах этого каталога.
- В дальнейшем - поддерживать эту структуру.
