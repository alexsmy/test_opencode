# Telegram notifications

## Режимы
- `server` — основной режим через Render.
- `local` — fallback для браузерной отправки, в случае недоступности серверных туннелей.

## Файлы
- `telegram-hub/telegram-route.json` — режим и endpoint.
- `telegram-hub/telegram-notify.json` — enabled и level.
- `telegram-hub/telegram-config.json` — токен бота + chat_id (только для local-режима, НЕ в git).
- `telegram-hub/notify.ps1` — Windows sender.
- `telegram-hub/notify.sh` — Linux sender.
- `telegram-hub/session-start.ps1` — уведомление о старте сессии.
- `telegram-hub/session-end.ps1` — уведомление о завершении.

## notfiy.ps1 — параметры

| Параметр | Обязательный | По умолчанию | Описание |
|----------|-------------|-------------|----------|
| `-Message` | да | — | Текст в HTML-формате |
| `-Kind` | нет | `single` | `single` / `update` |
| `-DeleteAfterSeconds` | нет | `0` | Автоудаление (0 = не удалять) |
| `-DisableWebPagePreview` | нет | `$true` | Отключить предпросмотр ссылок |
| `-MessageId` | нет | `0` | ID сообщения для `kind=update` |

## Серверный контракт (server-режим)

**POST** `/mytelegram`

Тело (JSON):
```json
{
  "text": "<b>текст</b>",
  "format": "html",
  "kind": "single",
  "disable_web_page_preview": true,
  "delete_after_seconds": 0,
  "message_id": 0
}
```

Заголовок: `X-Telegram-Tunnel-Secret: <секрет>`

## Конфиги

### telegram-route.json
```json
{
  "mode": "server",
  "server": {
    "endpoint": "https://bot-29-nx0w.onrender.com/mytelegram",
    "secret_env": "TELEGRAM_TUNNEL_SECRET",
    "timeout_seconds": 10,
    "format": "html"
  },
  "local": {
    "browser_timeout_seconds": 5
  }
}
```

- `mode`: `server` или `local`
- `server.endpoint` — URL для POST
- `server.secret_env` — имя env-переменной с секретом
- `server.timeout_seconds` — таймаут запроса
- `local.browser_timeout_seconds` — задержка перед закрытием окна браузера

### telegram-notify.json
```json
{
  "enabled": true,
  "level": "all"
}
```

- `enabled`: true/false — вкл/выкл уведомления
- `level`: `all` | `errors` — уровень детализации

## Переменные окружения

| Переменная | Описание |
|-----------|----------|
| `TELEGRAM_TUNNEL_SECRET` | Секретный ключ для server-режима |

## Правило
- Не дублировать логику отправки в документации и скриптах.
- Скрипты и конфиг — источник правды для Telegram.

## Команда `/tg`
- `on` — включить уведомления.
- `off` — выключить уведомления.
- `status` — показать статус.
- `on all` — все события.
- `on errors` — только ошибки.
