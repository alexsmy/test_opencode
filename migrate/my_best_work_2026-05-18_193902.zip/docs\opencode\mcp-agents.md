# MCP and agents

## Папки
- `agents-hub/` — серверные агенты, примеры MCP-инструментов, конфиги деплоя.
- `.opencode/agents/` — если появятся markdown-агенты OpenCode.
- `.opencode/skills/` — skills в формате `SKILL.md`.

## Протоколы

### MCP (новый, основной)
Подключение через opencode.jsonc:
```json
"mcp": {
  "weather_agents": {
    "type": "remote",
    "url": "https://bot-29-nx0w.onrender.com/mcp",
    "headers": { "x-agents-tunnel-secret": "{env:AGENTS_TUNNEL_SECRET}" },
    "enabled": true
  }
}
```

Инструменты: `get_weather`, `send_weather_to_telegram`, `send_telegram_message` и динамически загружаемые.

### REST API (старый, всё ещё работает)
Сервер Render (ветка mcp_agent_import):

| Метод | Путь | Назначение |
|-------|------|-----------|
| POST | `/api/agents/mcp-tools/register` | Загрузить MCP-тул |
| GET | `/api/agents/mcp-tools/list` | Список MCP-тулов |
| DELETE | `/api/agents/mcp-tools/{name}` | Удалить MCP-тул |
| POST | `/api/agents/upload` | Старый dynamic agent |
| GET | `/api/agents/list` | Список агентов |
| DELETE | `/api/agents/dynamic/{name}` | Удалить dynamic agent |
| POST | `/api/agents/inbox` | Старый протокол вызова |
| GET | `/api/agents/responses` | История ответов |
| GET | `/api/agents/responses/{file_id}` | Конкретный ответ |
| GET | `/api/agents/health` | Статус сервера |

Все (кроме health) требуют заголовок `X-Agents-Tunnel-Secret`.

Для старого протокола отдельные скрипты `agent-call.ps1` и `agents-tunnel.json` не обязательны — можно вызывать напрямую через Invoke-RestMethod.

### agent-deploy.json
Конфиг авто-деплоя динамических агентов при перезапуске Render (ephemeral storage recovery).

## Что держать отдельно
- Агентские инструкции — отдельно от проектных правил.
- Skills — отдельно от общих конфигов.
- MCP-описания — отдельно от Telegram и backup.

## Практика
- Для нового агента делать маленький файл с одной ролью.
- Для skills использовать `SKILL.md`.
- Не смешивать prompts, permissions и operational notes в одном месте.
