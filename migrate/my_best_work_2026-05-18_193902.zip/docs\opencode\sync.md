# Sync system

Синхронизация переносимого контекста между узлами через GitHub.

## Конфиг

`telegram-hub/sync.json` — настройки синхронизации, у каждого узла свои:

```json
{
  "repo": "ninamc4e/my_ai_opencode_server",
  "branch": "main",
  "files": ["HANDOVER.md", "CONTEXT.md", "USER.md"],
  "node_name": "notebook-win10",
  "push_after_task": true,
  "auto_sync_on_start": true,
  "auto_sync_on_end": true
}
```

Параметры:
- `repo` — GitHub-репозиторий для синхронизации
- `files` — какие файлы участвуют
- `node_name` — метка текущего узла (notebook-win10, notebook-win11, server)
- `push_after_task` — авто-синхронизация после каждой задачи
- `auto_sync_on_start` — синхронизация при старте сессии
- `auto_sync_on_end` — синхронизация при завершении

## Скрипты

| Файл | Платформа | Язык |
|------|-----------|------|
| `telegram-hub/sync.ps1` | Windows | PowerShell 5.1 |
| `telegram-hub/sync.sh` | Linux (Render, Alpine) | sh |

## Алгоритм работы sync.ps1

sync.ps1 выполняет два этапа: синхронизацию контекста и проверку архива.

### Этап 1. Синхронизация контекста (HANDOVER.md / CONTEXT.md / USER.md)

1. `git clone --depth 1` репозитория `ninamc4e/my_ai_opencode_server` во временную папку
2. Читает HANDOVER.md из клона (remote) и из локальной папки (local)
3. Сравнивает содержимое:
   - **remote = local** → ничего не делать (уже синхронизировано)
   - **local начинается как remote** → local новее (дописаны строки в этой сессии):
     - Скопировать local → remote (перезаписать)
   - **remote начинается как local** → remote новее (другая сессия на другом узле):
     - Найти строки в local, которых нет в remote
     - Дописать их в конец remote
   - **Полностью разные** → взять local (текущий узел важнее)
4. Копирует CONTEXT.md и USER.md local → remote по дате изменения (LastWriteTime)
5. Если были изменения: `git add` → `git commit` → `git push`

### Этап 2. Проверка архивного репозитория

После пуша sync проверяет, не появились ли более свежие версии системных файлов в архиве:

6. Клонирует `alexsmy/test_opencode` (архивный репозиторий)
7. Находит самый свежий `.zip` в папке `migrate/`
8. Извлекает из него `AGENTS.md` и `telegram-hub/sync.ps1` (Linux: `sync.sh`)
9. Сравнивает с локальными копиями — если архивная версия новее, обновляет локальные файлы
10. Удаляет временные папки

Это гарантирует, что при старте на любом узле будут самые актуальные правила и sync-скрипты, даже если на этом узле давно не обновляли файлы вручную.

## Auto-sync

- **При старте сессии**: sync после чтения HANDOVER.md/CONTEXT.md/USER.md
- **После каждой задачи**: sync с флагом `-Quiet` (без лишнего вывода)
- **При завершении сессии**: sync после обновления HANDOVER.md
- **Отключение**: `push_after_task: false` в `sync.json`

## Ручной sync

Команда `/sync` (или «синхронизируйся», «sync», «обнови контекст»):
1. Запустить sync.ps1 / sync.sh по платформе
2. Перечитать HANDOVER.md, CONTEXT.md, USER.md
3. Сообщить: «Триедино Синхронизирован. Дата: ...»
4. Отправить уведомление в Telegram (если enabled=true)
