---
name: code-reviewer
description: Review code for correctness, architecture, maintainability, and consistency with project rules.
compatibility: opencode
metadata:
  version: 1.0.0
  author: OpenAI
---

# Code Reviewer Skill

Use this skill when you need a focused review of code changes.

## What to check
- correctness of logic
- regressions against current project rules
- modularity and separation of concerns
- naming, readability, and consistency
- configuration drift between files that must stay aligned

## How to respond
- State whether the change is safe or needs revision.
- List the exact file-level issues.
- Suggest the minimal fix first.
- Do not rewrite unrelated modules.

## Important
- Prefer narrow, concrete feedback.
- Keep existing architecture intact.
- Escalate only when a change would break compatibility.
