# Telegram Hub

Подробные правила перенесены в `docs/opencode/telegram.md`.

Этот файл оставлен как краткая внешняя справка по Telegram-хабу.
