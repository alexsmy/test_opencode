# Контекст работы с OpenCode

Это текущий снимок состояния, а не длинная инструкция. Подробности вынесены в тематические файлы.

## Пользователь
- Имя: alexs
- GitHub: alexsmy
- Почта: alex.smyslov@mail.ru
- Язык общения: русский
- Уровень: начинающий программист

## Текущий узел
- **notebook-win10** — Windows 10, PowerShell, текущий рабочий узел

## Другие узлы
- **notebook-win11** — Windows 10, PowerShell
- **server** — Render / Alpine Linux, `sh` и `curl`

## Текущая рабочая папка
- `C:\Users\Alex1\Downloads\my_best_work`

## Что должно оставаться устойчивым
- `HANDOVER.md` — история действий
- `CONTEXT.md` — текущий снимок
- `USER.md` — предпочтения
- `docs/opencode/*.md` — тематические инструкции

## Где лежат подробности
- Структура проекта: `docs/opencode/project.md`
- Узлы и переносимость: `docs/opencode/nodes.md`
- Workflow: `docs/opencode/workflow.md`
- Синхронизация: `docs/opencode/sync.md`
- Telegram: `docs/opencode/telegram.md`
- Backup / restore: `docs/opencode/backup-restore.md`
- MCP и агенты: `docs/opencode/mcp-agents.md`
