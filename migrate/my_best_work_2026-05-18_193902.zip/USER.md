# Пользователь

## Основное
- Имя: alexs
- Позывной: alexs
- Язык общения: русский
- Модель по умолчанию: opencode/deepseek-v4-flash-free
- Часовой пояс: Europe/Moscow (UTC+3)

## Контакты
- GitHub: alexsmy
- Email: alex.smyslov@mail.ru

## Предпочтения
- Уведомления в Telegram: включены
- Уровень уведомлений: all
- Авто-синхронизация после каждой задачи: включена
- Синхронизация при старте сессии: включена
- Синхронизация при завершении сессии: включена

## Узлы
- `notebook-win10` — Windows 10
- `notebook-win11` — Windows 11
- `server` — Render / Alpine Linux

## Репозиторий синхронизации
https://github.com/alexsmy/test_opencode/tree/main/migrate
Именно сюда пушить архив после завершения сессии или перехода на другой компьютер.
