# Backup, restore, bootstrap

## Назначение
Эта группа файлов отвечает за безопасное сохранение и восстановление рабочей среды.

## Файлы
- `SCRIPTs/backup.ps1`
- `SCRIPTs/restore.ps1`
- `SCRIPTs/bootstrap.ps1`
- `SCRIPTs/seal.ps1`
- `SCRIPTs/unseal.ps1`
- `telegram-hub/cloud-migrate.ps1`

## Что важно
- Секреты не хранятся открытым текстом.
- Архив и восстановление должны работать на новом устройстве без ручной сборки контекста.
- При изменении backup/restore надо проверять, что sync и уведомления всё ещё согласованы.

## Где смотреть детали
Подробный порядок действий и роли узлов описываются в `docs/opencode/workflow.md` и `AGENTS.md`.
