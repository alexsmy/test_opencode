# Telegram Hub

## Режимы отправки

### Local mode (браузерный, fallback)
Открывает Chrome/Edge с невидимым Image(), который делает GET-запрос к Telegram Bot API.

```powershell
powershell -File telegram-hub/notify.ps1 -Message "<b>текст</b>"
```

Требует: `telegram-config.json` с токеном бота и chat_id.

### Server mode (через Render, основной)
Отправляет POST-запрос на серверный туннель с секретом из переменной окружения.

```powershell
powershell -File telegram-hub/notify.ps1 -Message "<b>текст</b>" -Kind "single"
```

Параметры:
- `-Message` (обязательный) — текст в HTML-формате
- `-Kind` — "single" | "replace" | "temporary" (по умолч. "single")
- `-DeleteAfterSeconds` — автоудаление (0 = не удалять)
- `-DisableWebPagePreview` — true/false (по умолч. true)
- `-MessageId` — ID сообщения для `kind=replace`

Требует: переменную окружения `TELEGRAM_TUNNEL_SECRET`.

> **Важно:** Telegram HTML parse mode поддерживает `<b>`, `<i>`, `<code>`, `<a>` и другие теги, но **не поддерживает** `<br>`. Для переноса строки используйте символ `\n` (backtick-n в PowerShell: `"text1`n`ntext2"`).

## Переменные окружения

| Переменная | Описание |
|---|---|
| `TELEGRAM_TUNNEL_SECRET` | Секретный ключ для server-режима |

## Конфигурация

### telegram-route.json
```json
{
  "mode": "server",
  "server": {
    "endpoint": "https://bot-29-nx0w.onrender.com/mytelegram",
    "secret_env": "TELEGRAM_TUNNEL_SECRET",
    "timeout_seconds": 10,
    "format": "html"
  },
  "local": {
    "browser_timeout_seconds": 5
  }
}
```

- `mode`: `"server"` или `"local"`
- `server.endpoint` — URL для POST
- `server.secret_env` — имя env-переменной с секретом
- `server.timeout_seconds` — таймаут запроса
- `local.browser_timeout_seconds` — задержка перед закрытием окна браузера

### telegram-notify.json
```json
{
  "enabled": true,
  "level": "all"
}
```

- `enabled`: true/false — вкл/выкл уведомления
- `level`: "all" | "errors" — уровень детализации

## Серверный контракт

**POST** `/mytelegram`

Тело (JSON):
```json
{
  "text": "<b>текст</b>",
  "format": "html",
  "kind": "single",
  "disable_web_page_preview": true,
  "delete_after_seconds": 0,
  "message_id": 0
}
```

Заголовок: `X-Telegram-Tunnel-Secret: <секрет>`
